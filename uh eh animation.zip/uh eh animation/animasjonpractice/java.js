
//CLASSES


class object {
    constructor(navn, sprite, width, height, weight, xspd, yspd, xposition, yposition) {
        this.navn = navn;
        this.sprite = sprite;
        this.width = width;
        this.height = height;
        this.weight = weight;
        this.xspd = xspd;
        this.yspd = yspd;
        this.xposition = xposition;
        this.yposition = yposition;


        this.collition = function (obj) {
            var objmidtpunktx = (obj.xposition + obj.width / 2);
            var objmidtpunktY = (obj.yposition + obj.height / 2);
            var mainobjx = (this.xposition + this.width / 2);
            var mainobjy = (this.yposition + this.height / 2);
            var vx = mainobjx - objmidtpunktx;
            var vy = mainobjy - objmidtpunktY;
            var halfwidth = (this.width + obj.width) / 2;
            var halfheight = (this.height + obj.height) / 2;
            var collitiondirection = null;
            var ox = halfwidth - Math.abs(vx);
            var oy = halfheight - Math.abs(vy);

            if (Math.abs(vx) < halfwidth && Math.abs(vy) < halfheight) {

                if (ox >= oy) {

                    if (vy > 0) {
                        collitiondirection = "topp";
                        this.yposition += 10;
                    } else {
                        collitiondirection = "bunn";
                        this.yposition += -10;
                    }

                } else {
                    if (vx > 0) {
                        collitiondirection = "left";
                        this.xposition += 10;

                    } else {
                        collitiondirection = "right";
                        this.xposition += -10;
                    }
                }




                // hvis vx eller vy er mindre enn halfheight og  halfwidth, så kolliderer de. vis vy er positiv så er det kollisjon på topp, mens i minus er det på bunn. 




            }
            return collitiondirection;


        }
    }
}


//VARIABLES
var playerimage = new Image();
playerimage.src = "../imgages/mainplayer.jpg";
var blockimage = new Image();
blockimage.src = "../imgages/blocketyblockblock.png"

//constructor(navn, sprite, width, height, weight, xspd, yspd, xposition, yposition)
var player = new object("charliebrown", playerimage, 100, 129, 0.5, 10, 10, 960 / 2, 720 / 2);
var down = false;
var left = false;
var right = false;
var up = false;
var gravityforce = 20;





var canvas = document.getElementById("asscanvas");

var ctx = canvas.getContext("2d");
window.addEventListener("keydown", movement);
window.addEventListener("keyup", movementoff)



//CONTROLLS

function movement(e) {


    // console.log("test kontroll");
    if (e.keyCode === 39) {
        right = true;
    }
    if (e.keyCode === 37) {
        left = true;
    }
    if (e.keyCode === 38) {
        up = true;

    }
    if (e.keyCode === 40) {
        down = true;

    }
}


function movementoff(e) {

    //console.log("test kontroll av");
    if (e.keyCode === 39) {
        right = false;
    }
    if (e.keyCode === 37) {
        left = false;
    }
    if (e.keyCode === 38) {
        up = false;

    }
    if (e.keyCode === 40) {
        down = false;

    }
}
var blockarray = [];

//constructor(navn, sprite, width, height, weight, xspd, yspd, xposition, yposition)
var blockset = [
    {
        antallblokker: Math.floor(15 * Math.random()),
        width: 60,
        height: 60,
        xposition: 20,
        yposition: 20
    },
    {
        antallblokker: Math.floor(5 * Math.random()),
        width: 60,
        height: 60,
        xposition: 20,
        yposition: 300
    },
    {
        antallblokker: Math.floor(5 * Math.random()),
        width: 60,
        height: 60,
        xposition: 400,
        yposition: 300
    },
    {
        antallblokker: 5,
        width: 60,
        height: 60,
        xposition: canvas.width / 2,
        yposition: canvas.height / 1.5 + player.height
    },

];

for (i = 0; i < blockset.length; i++) {
    for (j = 0; j < blockset[i].antallblokker; j++) {
        console.log(blockset[i].antallblokker);
        blockarray.push(
            {
                width: blockset[i].width,
                height: blockset[i].height,
                xposition: blockset[i].xposition + j * 60,
                yposition: blockset[i].yposition
            }
        )
    }
};


console.log(blockarray);