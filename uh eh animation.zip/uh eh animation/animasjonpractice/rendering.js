
//RENDER
function render() {



    if (right) {
        player.xposition += player.xspd;
    }
    if (left) {
        player.xposition += -player.xspd;
    }


    if (up) {

        player.yposition += -player.xspd;
    }

    if (!right && !left) {
        player.xposition += 0;
    }

    if (down) {
        player.yposition += player.xspd;
    }
    if (player.yspd < gravityforce) {
        player.yspd += player.weight;
    }

    //COLLITION CHECK
    for (i = 0; i < blockarray.length; i++) {


        if (player.collition(blockarray[i]) === "bunn") {


        }
    };

    ctx.clearRect(0, 0, canvas.width, canvas.height);


    ctx.drawImage(player.sprite, player.xposition, player.yposition);

    for (i = 0; i < blockarray.length; i++) {

        ctx.drawImage(blockimage, blockarray[i].xposition, blockarray[i].yposition, blockarray[i].width, blockarray[i].height);

    };

    //console.log("xposisjon:" + player.xposition, "yposisjon:" + player.yposition);
    //console.log("spiller sprite:" + player.sprite);


    requestAnimationFrame(render);
};


requestAnimationFrame(render);